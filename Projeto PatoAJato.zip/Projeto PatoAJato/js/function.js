// class AquecedorMotor {
//     constructor(potenciaMaxima, temperaturaMinima, temperaturaMaxima) {
//       this.potenciaMaxima = potenciaMaxima;
//       this.temperaturaAtual = temperaturaMinima; // Começa na temperatura mínima
//       this.temperaturaMinima = temperaturaMinima;
//       this.temperaturaMaxima = temperaturaMaxima;
//       this.ligado = false;
//     }
  
//     ligar() {
//       if (!this.ligado) {
//         console.log("Aquecedor ligado.");
//         this.ligado = true;
//         this.mostrarStatus();
//       }
//     }
  
//     desligar() {
//       if (this.ligado) {
//         console.log("Aquecedor desligado.");
//         this.ligado = false;
//         this.mostrarStatus();
//       }
//     }
  
//     aumentarTemperatura(incremento) {
//       if (this.ligado) {
//         const novaTemperatura = this.temperaturaAtual + incremento;
//         if (novaTemperatura <= this.temperaturaMaxima) {
//           this.temperaturaAtual = novaTemperatura;
//           console.log(`Temperatura atual: ${this.temperaturaAtual}°C`);
//         } else {
//           console.log("Aquecedor atingiu a temperatura máxima.");
//         }
//         this.mostrarStatus();
//       } else {
//         console.log("Aquecedor desligado. Ligue o aquecedor primeiro.");
//       }
//     }
  
//     diminuirTemperatura(decremento) {
//       if (this.ligado) {
//         const novaTemperatura = this.temperaturaAtual - decremento;
//         if (novaTemperatura >= this.temperaturaMinima) {
//           this.temperaturaAtual = novaTemperatura;
//           console.log(`Temperatura atual: ${this.temperaturaAtual}°C`);
//         } else {
//           console.log("Aquecedor atingiu a temperatura mínima.");
//         }
//         this.mostrarStatus();
//       } else {
//         console.log("Aquecedor desligado. Ligue o aquecedor primeiro.");
//       }
//     }
  
//     mostrarStatus() {
//       const status = this.ligado ? "Ligado" : "Desligado";
//       console.log(`Status: ${status}`);
//     }
//   }
  
//   // Criando uma instância do aquecedor com as especificações
//   const aquecedor = new AquecedorMotor(1000, 80, 110);
  
//   // Exibindo o status inicial
//   aquecedor.mostrarStatus();
  
//   // Ligar o aquecedor
//   aquecedor.ligar();
  
//   // Aumentar a temperatura em 10 graus
//   aquecedor.aumentarTemperatura(10);
  
//   // Desligar o aquecedor
//   aquecedor.desligar();
  

//   // Inicializa a temperatura do carro em 0°C
// let temperaturaCarro = 0;

// // Loop para simular o aumento de temperatura em incrementos de 20°C
// while (temperaturaCarro <= 90) {
//   console.log(`A temperatura do carro é de ${temperaturaCarro}°C`);
//   temperaturaCarro += 20;
// }

// console.log("O carro atingiu 90°C e precisa esfriar.");


