// // Função para ligar a bomba
// function ligarBomba() {
//     if (!bombaLigada) {
//         bombaLigada = true;
//         mensagemElement.textContent = "A bomba foi ligada.";
//     }
// }

// // Função para desligar a bomba
// function desligarBomba() {
//     if (bombaLigada) {
//         bombaLigada = false;
//         mensagemElement.textContent = "A bomba foi desligada.";
//     }
// }


// function ligarCarro() {
//     if (!carroLigado) {
//         carroLigado = true;
//         mensagemElement.textContent = "O carro foi ligado.";
//         atualizarTemperatura();
//         iniciarSimulacao();
//     }
// }

// // Função para desligar o carro
// function desligarCarro() {
//     if (carroLigado) {
//         carroLigado = false;
//         temperaturaCarro = 0; // Reseta a temperatura para 0°C
//         mensagemElement.textContent = "O carro foi desligado.";
//         atualizarTemperatura();
//         clearInterval(simulacao);
//     }
// }

// // Função para iniciar a simulação
// function iniciarSimulacao() {
//     if (carroLigado) {
//         ligarBomba();
//         simulacao = setInterval(aumentarTemperatura, 2000); // Aumenta a cada 2 segundos (2000 milissegundos)
//     }
// }

// // Função para ligar o sistema geral
// function ligarGeral() {
//     ligarCarro();
// }

